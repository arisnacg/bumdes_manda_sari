<?php $__env->startSection("title"); ?>
	<?php echo e($artikel_program->judul); ?> -
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb -->
	<div class="container">
		<div class="headline bg0 flex-wr-sb-c p-rl-20 p-tb-8">
			<div class="f2-s-1 p-r-30 m-tb-6">
				<a href="/" class="breadcrumb-item f1-s-3 cl9">
					Beranda 
				</a>
				<a href="<?php echo e(route("page.daftar_blog")); ?>" class="breadcrumb-item f1-s-3 cl9">
					Artikel
				</a>
				<span class="breadcrumb-item f1-s-3 cl9">
					<?php echo e($artikel_program->judul); ?>

				</span>
			</div>

			<form method="GET" action="<?php echo e(route("page.daftar_blog")); ?>">
				<div class="pos-relative size-a-2 bo-1-rad-22 of-hidden bocl11 m-tb-6">
					<input class="f1-s-1 cl6 plh9 s-full p-l-25 p-r-45" type="text" name="search" placeholder="Search">
					<button type="submit" class="flex-c-c size-a-1 ab-t-r fs-20 cl2 hov-cl10 trans-03">
						<i class="zmdi zmdi-search"></i>
					</button>
				</div>
			</form>
		</div>
	</div>
	<!-- Content -->
	<section class="bg0 p-b-70 p-t-5">
		<!-- Title -->
		<div class="bg-img1 size-a-18 how-overlay1" style="background-image: url(<?php echo e(asset("website/images/artikel_program/".$artikel_program->gambar)); ?>);">
			<div class="container h-full flex-col-e-c p-b-58">
				<a href="#" class="f1-s-10 cl0 hov-cl10 trans-03 text-uppercase txt-center m-b-33">
					<?php echo e($artikel_program->program->nama); ?>

				</a>

				<h3 class="f1-l-5 cl0 p-b-16 txt-center respon2">
					<?php echo e($artikel_program->judul); ?>

				</h3>

				<div class="flex-wr-c-s">
					<span class="f1-s-3 cl0 m-r-15">
						<a href="#" class="f1-s-4 cl0 hov-cl10 trans-03">
							oleh <?php echo e($artikel_program->penulis->nama); ?>

						</a>
						<span class="m-rl-3">-</span>
						<span>
							Terbit <?php echo e($artikel_program->created_at->format("d M, Y")); ?>

						</span>
						<span class="m-l-10">
							Update <?php echo e($artikel_program->updated_at->format("d M, Y")); ?>

						</span>
					</span>
					<span class="f1-s-3 cl0 m-r-15">
						Dikunjungi <?php echo e($artikel_program->dikunjungi); ?>

					</span>
				</div>
			</div>
		</div>
		<?php if(!Auth::guest()): ?>
			<?php if(Auth::user()->id_jenis == 1): ?>
				<div class="text-center m-t-40">
					<a href="<?php echo e(route("artikel_program.edit", ["id" =>$artikel_program->id])); ?>" class="size-h-2 bo-1-rad-20 bocl12 f1-s-1 cl8 hov-btn2 trans-03 p-rl-20 p-tb-5 m-all-5">
						Edit Artikel
					</a>
					<a href="<?php echo e(route("artikel_program.gambar", ["id" =>$artikel_program->id])); ?>" class="size-h-2 bo-1-rad-20 bocl12 f1-s-1 cl8 hov-btn2 trans-03 p-rl-20 p-tb-5 m-all-5">
						Ganti Gambar
					</a>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<!-- Detail -->
		<div class="container p-t-60">
			<div class="row justify-content-center">
				<div class="col-md-10 col-lg-8 p-b-100">
					<div class="p-r-10 p-r-0-sr991">
						<!-- Blog Detail -->
						<div class="p-b-70">
							<!-- Deskripsi -->
							<div class="deskripsi">
								<?php echo $artikel_program->isi; ?>

							</div>

							<!-- Tag -->
							

							<!-- Share -->
							<div class="flex-s-s m-t-40">
								<span class="f1-s-12 cl5 p-t-1 m-r-15">
									Share:
								</span>
								<?php echo Share::currentPage($artikel_program->judul, [], '', '')->facebook()->twitter()->whatsapp()->telegram(); ?>

							</div>
							
						</div>
					</div>
				</div>
				
				<div class="col-md-10 col-lg-4 p-b-100">
					<div class="p-l-10 p-rl-0-sr991">
						<?php echo $__env->make("inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
	<script src="<?php echo e(asset('js/share.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/baca_artikel_program.blade.php ENDPATH**/ ?>