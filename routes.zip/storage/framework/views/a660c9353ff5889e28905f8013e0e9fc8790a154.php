<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Edit']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(route("blog.index")); ?>">Blog</a></a></li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row">
                <div class="col-sm-12">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="panel panel-default">
                        <div class="panel-heading"><?php echo e($row->judul); ?> <span class="label label-info m-l-5">Edit</span></div>
                        <div class="panel-wrapper collapse in">
                            <div class="panel-body">
                                <form method="POST" action="<?php echo e(route("blog.update", ["id" => $row->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("PUT"); ?>
                                        <div class="text-right m-b-40">
                                            <a target="_blank" href="<?php echo e(route("page.blog", ['url' => $row->url])); ?>" class="btn btn-primary waves-effect waves-light" type="button">
                                                <span class="btn-label"><i class=" zmdi zmdi-eye"></i></span> Preview Halaman
                                            </a>
                                            <a href="<?php echo e(route("blog.gambar", ["id" => $row->id])); ?>" class="btn btn-info waves-effect waves-light" type="button">
                                                <span class="btn-label"><i class=" zmdi zmdi-image"></i></span> Ganti Gambar
                                            </a>
                                            <button type="submit" class="btn btn-success waves-effect waves-light" type="button">
                                                <span class="btn-label"><i class=" zmdi zmdi-save"></i></span> Update Blog
                                            </button>
                                        </div>
                                        <div class="form-group row <?php echo e($errors->has('judul') ? 'has-danger' : ''); ?>">
                                            <label class="col-sm-12 col-md-2">Judul Blog</label>
                                            <div class="col-sm-12 col-md-10">
                                                <input name="judul" type="text" class="form-control" value="<?php echo e($row->judul); ?>">
                                                <?php if($errors->has('judul')): ?>
                                                    <div class="form-control-feedback"><?php echo e($errors->first('judul')); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row <?php echo e($errors->has('id_kategori') ? 'has-danger' : ''); ?>">
                                            <label class="col-sm-12 col-md-2">Kategori Blog</label>
                                            <div class="col-sm-12 col-md-5">
                                                <select name="id_kategori" class="form-control">
                                                    <?php $__currentLoopData = $kategori_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($e->id); ?>"
                                                            <?php if($row->id_kategori == $e->id): ?> selected <?php endif; ?>
                                                            ><?php echo e($e->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('id_kategori')): ?>
                                                    <div class="form-control-feedback"><?php echo e($errors->first('id_kategori')); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <label class="m-b-10">Isi Konten Blog</label>
                                        <?php if($errors->has('isi')): ?>
                                            <div class="form-control-feedback m-b-10 text-danger"> <?php echo e($errors->first('isi')); ?> </div>
                                            </span>
                                        <?php endif; ?>
                                        <textarea id="editor" name="isi" class="summernote"><?php echo $row->isi; ?></textarea>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
    </div>
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/plugins/bower_components/summernote/dist/summernote.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bower_components/summernote/dist/summernote.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<script>
    $('.summernote').summernote({
        toolbar: [
            ['style', ['style']],
            ['fontsize', ['fontsize']],
            ['font', ['bold', 'italic', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['insert', ['picture', 'hr']],
            ['table', ['table']]
        ],
        fontSizes: ['8', '9', '10', '11', '12', '14', '16', '18', '24', '36', '48' , '64', '82', '150'],
        height: 800, // set editor height
        minHeight: null, // set minimum height of editor
        maxHeight: null, // set maximum height of editor
        focus: false, // set focus to editable area after initializing summernote
        fontNames: ['Poppins', 'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New']
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/blog/edit.blade.php ENDPATH**/ ?>