<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Gallery Usaha']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(route("unit_usaha.index")); ?>">Usaha</a></li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row justify-content-center">
                <div class="col-sm-12">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="white-box">
                        <h5><?php echo e($unit_usaha->nama); ?></h5>
                        <hr>
                        <div class="text-right">
                            <a target="_blank" href="<?php echo e(route("page.unit_usaha", ['url' => $unit_usaha->url])); ?>" class="btn btn-primary waves-effect waves-light" type="button">
                                <span class="btn-label"><i class=" zmdi zmdi-eye"></i></span> Preview Halaman
                            </a>
                            <a href="<?php echo e(route('gallery_usaha.add', ['id_unit_usaha' => $unit_usaha->id])); ?>" class="btn btn-success waves-effect waves-light" type="button"><span class="btn-label"><i class=" zmdi zmdi-plus-circle"></i></span>Tambah Baru</a>
                        </div>
                        <hr>
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-12 col-md-3 p-b-40">
                                    <img src="<?php echo e('/website/images/gallery_usaha/'.$row->gambar); ?>" width="100%">
                                     <div class="text-center m-t-10">
                                        <button data-id="<?php echo e($row->id); ?>" class="btn btn-delete-jenis-unit-usaha btn-danger waves-effect waves-light"
                                            type="button"><span class="btn-label"><i class="zmdi zmdi-delete"></i></span>Hapus</button>
                                        <form id="formDelete<?php echo e($row->id); ?>" method="POST" action="<?php echo e(route('gallery_usaha.destroy', ['id' => $row->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/gallery_usaha/index.blade.php ENDPATH**/ ?>