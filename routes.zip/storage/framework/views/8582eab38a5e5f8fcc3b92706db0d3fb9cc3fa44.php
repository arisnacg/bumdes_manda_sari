<input class="f1-s-1 cl6 plh9 s-full p-l-25 p-r-45" type="text" name="search" placeholder="Search">
<button class="flex-c-c size-a-1 ab-t-r fs-20 cl2 hov-cl10 trans-03">
	<i class="zmdi zmdi-search"></i>
</button><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/inc/search_bar.blade.php ENDPATH**/ ?>