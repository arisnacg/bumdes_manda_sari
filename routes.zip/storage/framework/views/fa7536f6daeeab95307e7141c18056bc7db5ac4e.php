<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Tambah']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(route("unit_usaha.index")); ?>">Unit Usaha</li>
            <li><a href="<?php echo e(route("gallery_usaha.gallery", ["id_unit_usaha" => $unit_usaha->id])); ?>">Gallery</li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row">
                <div class="col-sm-12">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="panel panel-default">
                        <div class="panel-heading"><?php echo e($unit_usaha->nama); ?></div>
                        <div class="panel-wrapper collapse in">
                            <div class="panel-body">
                                <div class="text-left m-b-20">
                                    <a target="_blank" href="<?php echo e(route("page.unit_usaha", ['url' => $unit_usaha->url])); ?>" class="btn btn-primary waves-effect waves-light" type="button">
                                        <span class="btn-label"><i class=" zmdi zmdi-eye"></i></span> Preview Halaman
                                    </a>
                                    <button class="btn btn-info waves-effect waves-light" id="btnGambar" type="button">
                                        <span class="btn-label"><i class="zmdi zmdi-image"></i></span> Pilih Gambar
                                    </button>
                                    <button id="uploadGambar" class="btn btn-success waves-effect waves-light" type="button">
                                        <span class="btn-label"><i class=" zmdi zmdi-save"></i></span> Simpan Gambar
                                    </button>
                                </div>
                                <hr>
                                <input id="inputGambar" type="file" name="image" class="image" style="display: none;">
                                <div class="img-container">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h5 style="display: none;" class="text-muted info-cropper">Info: Anda dapat zoom-in/zoom-out gambar menggunakan <b>Mouse Scroll</b></h5>
                                            <img class="img-cropper" id="image" src="">
                                        </div>
                                        <div class="col-md-4">
                                            <div class="text-center">
                                                <h4 class="muted">Hasil Crop :</h4>
                                                <div class="preview"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
    </div>
     
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/plugins/bower_components/cropper/cropper.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    var ID_USAHA = <?php echo e($unit_usaha->id); ?>;
</script>
<script src="<?php echo e(asset('admin/plugins/bower_components/cropper/cropper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/upload_gambar/gallery_usaha.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/gallery_usaha/create.blade.php ENDPATH**/ ?>