<?php $__env->startSection("title"); ?>
	<?php if($req->search): ?>
		Hasil pencarian untuk "<?php echo e($req->search); ?>"
	<?php elseif($jenis_usaha): ?>
		<?php echo e($jenis_usaha->nama); ?>

	<?php else: ?>
		Usaha
	<?php endif; ?>
	 - 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		
	<!-- Breadcrumb -->
	<div class="container">
		<div class="bg0 flex-wr-sb-c p-rl-20 p-tb-8">
			<div class="f2-s-1 p-r-30 m-tb-6">
				<a href="/" class="breadcrumb-item f1-s-3 cl9">
					Beranda
				</a>
				<span class="breadcrumb-item f1-s-3 cl9">
					Usaha
				</span>
			</div>
			
			<form method="GET" action="<?php echo e(route("page.daftar_usaha")); ?>">
				<div class="pos-relative size-a-2 bo-1-rad-22 of-hidden bocl11 m-tb-6">
					<input class="f1-s-1 cl6 plh9 s-full p-l-25 p-r-45" type="text" name="search" placeholder="Search" value="<?php echo e($req->search); ?>">
					<button type="submit" class="flex-c-c size-a-1 ab-t-r fs-20 cl2 hov-cl10 trans-03">
						<i class="zmdi zmdi-search"></i>
					</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Page heading -->
	<div class="container p-t-4 p-b-40">
		<?php if($req->search): ?>
			<h5 class="f1-l-1 cl2" style="font-size: 24px"> Hasil pencarian untuk <span class="text-success"><?php echo e($req->search); ?></span></h5>
		<?php elseif($jenis_usaha): ?>
			<h5 class="f1-l-1 cl2" style="font-size: 24px"> <span class="text-success"><?php echo e($jenis_usaha->nama); ?></span></h5>
		<?php else: ?>
			<h2 class="f1-l-1 cl2">Usaha</h2>
		<?php endif; ?>
	</div>

	<!-- Post -->
	<section class="bg0 p-t-40 p-b-55">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 col-lg-8 p-b-80">
					<div class="row">
						<?php $__currentLoopData = $daftar_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_usaha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-6 p-r-25 p-r-15-sr991">
								<!-- Item latest -->	
								<div class="m-b-45">
									<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="wrap-pic-w hov1 trans-03">
										<img src="<?php echo e(asset("website/images/usaha/".$unit_usaha->gambar)); ?>" alt="IMG">
									</a>

									<div class="p-t-16">
										<h5 class="p-b-5">
											<a href="blog-detail-01.html" class="f1-m-3 cl2 hov-cl10 trans-03">
												<?php echo e($unit_usaha->nama); ?>

											</a>
										</h5>

										<div class="cl8">
											<a href="#" class="f1-s-4 cl8 hov-cl10 trans-03">
												oleh <?php echo e($unit_usaha->penulis->nama); ?>

											</a>

											<span class="f1-s-3 m-rl-3">
												-
											</span>

											<span class="f1-s-3">
												Terbit <?php echo e($unit_usaha->created_at->format("d M, Y")); ?>

											</span>
										</div>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

					<?php echo e($daftar_usaha->links()); ?>

				</div>

				<div class="col-md-10 col-lg-4 p-b-80">
					<div class="p-l-10 p-rl-0-sr991">							
						<?php echo $__env->make("inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
		
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/daftar_usaha.blade.php ENDPATH**/ ?>