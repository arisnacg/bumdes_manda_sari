<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Artikel Program']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row justify-content-center">
                <div class="col-sm-12">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="white-box">
                        <div class="text-right">
                            <a href="<?php echo e(route('artikel_program.create')); ?>" class="btn btn-success waves-effect waves-light"
                                type="button"><span class="btn-label"><i class=" zmdi zmdi-plus-circle"></i></span>Tambah Baru</a>
                        </div>
                        <div class="m-t-20">
                            <table class="table table-hover" id="tableTour">
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th>Nama</th>
                                        <th>Program</th>
                                        <th>Terbit</th>
                                        <th class="text-center">Dikunjungi</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($data)): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($i +1); ?></td>
                                        <td><a target="_blank" href="<?php echo e(route("page.artikel_program", ["url" => $row->url])); ?>"><?php echo e($row->judul); ?></a></td>
                                        <td><?php echo e($row->program->nama); ?></td>
                                        <td><?php echo e($row->created_at->format("d/m/Y")); ?></td>
                                        <td class="text-center"><?php echo e($row->dikunjungi); ?></td>
                                        <td class="text-center">   
                                            <a href="<?php echo e('/website/images/artikel_program/'.$row->gambar); ?>" target="_blank" class="btn btn-info waves-effect waves-light">
                                                <i class="zmdi zmdi-image"></i>
                                            </a>
                                            <a href="<?php echo e(route('artikel_program.edit', ['id' => $row->id])); ?>" class="btn btn-warning waves-effect waves-light">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <button data-id="<?php echo e($row->id); ?>" class="btn btn-delete-artikel-program btn-danger waves-effect waves-light"
                                                type="button"><i class="zmdi zmdi-delete"></i>
                                            </button>
                                            <form id="formDelete<?php echo e($row->id); ?>" method="POST" action="<?php echo e(route('artikel_program.destroy', ['id' => $row->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("DELETE"); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<script>
    $("#tableTour").DataTable()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/artikel_program/index.blade.php ENDPATH**/ ?>