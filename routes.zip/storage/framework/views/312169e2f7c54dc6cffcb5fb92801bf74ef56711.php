<div class="row bg-title">
  <!-- .page title -->
  <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
    <h4 class="page-title"><?php echo e($pagename); ?></h4>
  </div>
  <!-- /.page title -->
  <!-- .breadcrumb -->
  <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
    <ol class="breadcrumb">
        <?php echo e($slot); ?>

        <li class="active"><?php echo e($pagename); ?></li>
    </ol>
  </div>
  <!-- /.breadcrumb -->
</div><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/components/breadcrumb.blade.php ENDPATH**/ ?>