
<!-- Popular Posts -->
<div class="p-b-30">
	<div class="how2 how2-cl4 flex-s-c">
		<h3 class="f1-m-2 cl3 tab01-title">
			Postingan Populer
		</h3>
	</div>

	<ul class="p-t-35">
		<?php if(count($data["blog_populer"])): ?>
			<?php $__currentLoopData = $data["blog_populer"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="flex-wr-sb-s p-b-30">
					<a href="<?php echo e(route("page.blog", ["url" => $e->url])); ?>" class="size-w-10 wrap-pic-w hov1 trans-03">
						<img src="<?php echo e(asset("website/images/blog/".$e->gambar)); ?>" alt="IMG">
					</a>

					<div class="size-w-11">
						<h6 class="p-b-4">
							<a href="<?php echo e(route("page.blog", ["url" => $e->url])); ?>" class="f1-s-5 cl3 hov-cl10 trans-03">
								<?php echo e($e->judul); ?>

							</a>
						</h6>

						<span class="cl8 txt-center p-b-24">
							<a href="#" class="f1-s-6 cl8 hov-cl10 trans-03">
								<?php echo e($e->kategori->nama); ?>

							</a>

							<span class="f1-s-3 m-rl-3">
								-
							</span>

							<span class="f1-s-3">
								Terbit <?php echo e($e->created_at->format("d M, Y")); ?>

							</span>
						</span>
					</div>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</ul>
</div>

<!-- Category Blog -->
<div class="p-b-60">
	<div class="how2 how2-cl4 flex-s-c">
		<h3 class="f1-m-2 cl3 tab01-title">
			Jenis Usaha
		</h3>
	</div>

	<ul class="p-t-35">
		<?php $__currentLoopData = $data["jenis_unit_usaha"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="how-bor3 p-rl-4">
				<a href="<?php echo e(route("page.daftar_usaha", ["id_jenis" => $e->id])); ?>" class="dis-block f1-s-10 text-uppercase cl2 hov-cl10 trans-03 p-tb-13">
					<?php echo e($e->nama); ?>

				</a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>

<!-- Category Blog -->

				
<!-- Category Blog -->
<div class="p-b-60">
	<div class="how2 how2-cl4 flex-s-c">
		<h3 class="f1-m-2 cl3 tab01-title">
			Kategori Blog
		</h3>
	</div>

	<ul class="p-t-35">
		<?php $__currentLoopData = $data["kategori_blog"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="how-bor3 p-rl-4">
			<a href="<?php echo e(route("page.daftar_blog", ["id_kategori" => $e->id])); ?>" class="dis-block f1-s-10 text-uppercase cl2 hov-cl10 trans-03 p-tb-13">
				<?php echo e($e->nama); ?>

			</a>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>


<!-- Archive -->
<div class="p-b-37">
	<div class="how2 how2-cl4 flex-s-c">
		<h3 class="f1-m-2 cl3 tab01-title">
			Arsip Blog
		</h3>
	</div>
	<?php
		$arr_bulan = [
			"Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"
		]
	?>

	<ul class="p-t-32">
		<?php $__currentLoopData = $data["arsip"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="p-rl-4 p-b-19">
				<a href="<?php echo e(route("page.daftar_blog", ["bulan" => $e->month, "tahun" => $e->year])); ?>" class="flex-wr-sb-c f1-s-10 text-uppercase cl2 hov-cl10 trans-03">
					<span>
						<?php echo e($arr_bulan[$e->month-1]." ".$e->year); ?>

					</span>

					<span>
						(<?php echo e($e->data); ?>)
					</span>
				</a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>


<!-- Tag -->

<?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>