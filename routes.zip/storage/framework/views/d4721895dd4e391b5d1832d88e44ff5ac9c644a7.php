<?php $__env->startSection("title"); ?>
	<?php if($req->search): ?>
		Hasil pencarian untuk "<?php echo e($req->search); ?>"
	<?php elseif($anggota): ?>
		<?php echo e($anggota->nama); ?>

	<?php endif; ?>
	 - 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		
	<!-- Breadcrumb -->
	<div class="container">
		<div class="bg0 flex-wr-sb-c p-rl-20 p-tb-8">
			<div class="f2-s-1 p-r-30 m-tb-6">
				<a href="/" class="breadcrumb-item f1-s-3 cl9">
					Beranda
				</a>
				<a href="<?php echo e(route("page.program", ["url" => $anggota->program->url])); ?>" class="breadcrumb-item f1-s-3 cl9">
					<?php echo e($anggota->program->judul); ?>

				</a>
				<span class="breadcrumb-item f1-s-3 cl9">
					<?php echo e($anggota->nama); ?>

				</span>
			</div>
			
			<form method="GET" action="<?php echo e(route("page.daftar_usaha")); ?>">
				<div class="pos-relative size-a-2 bo-1-rad-22 of-hidden bocl11 m-tb-6">
					<input class="f1-s-1 cl6 plh9 s-full p-l-25 p-r-45" type="text" name="search" placeholder="Search" value="<?php echo e($req->search); ?>">
					<button type="submit" class="flex-c-c size-a-1 ab-t-r fs-20 cl2 hov-cl10 trans-03">
						<i class="zmdi zmdi-search"></i>
					</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Post -->
	<section class="bg0 p-t-20 p-b-55">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 col-lg-8 p-b-80" style="padding: 0 30px 40px">
					<div class="text-center">
						<span class="text-success f1-s-10 cl2 hov-cl10 trans-03 text-uppercase">ANGGOTA</span>
						<h4 style="font-size: 20px" class="f1-l-3 cl2 p-b-16 p-t-16 respon2">
							<?php echo e($anggota->program->judul); ?>

						</h4>
						<img class="m-t-20" width="150" src="<?php echo e(asset("website/images/anggota_program/".$anggota->foto)); ?>" alt="IMG">
					</div>
					<ul class="list-group m-t-20">
						 <li class="list-group-item row justify-content-start d-flex">
						 	<div class="col-sm-12 col-md-2"><b>Nama</b></div>
						 	<div class="col-sm-12 col-md-9"><?php echo e($anggota->nama); ?></div>
						 </li>
						 <li class="list-group-item row justify-content-start d-flex">
						 	<div class="col-sm-12 col-md-2"><b>Umur</b></div>
						 	<div class="col-sm-12 col-md-9"><?php echo e($anggota->umur); ?> Tahun</div>
						 </li>
						 <li class="list-group-item row justify-content-start d-flex">
						 	<div class="col-sm-12 col-md-2"><b>Pekerjaan</b></div>
						 	<div class="col-sm-12 col-md-9"><?php echo e($anggota->pekerjaan); ?></div>
						 </li>
						 <li class="list-group-item row justify-content-start d-flex">
						 	<div class="col-sm-12 col-md-2"><b>Alamat</b></div>
						 	<div class="col-sm-12 col-md-9"><?php echo e($anggota->alamat); ?></div>
						 </li>
					</ul>
					<div class="deskripsi m-t-20">
						<h2 class="text-success"><b>Informasi Tambahan :</b></h2>
						<?php echo $anggota->informasi; ?>

					</div>
				</div>

				<div class="col-md-10 col-lg-4 p-b-80">
					<div class="p-l-10 p-rl-0-sr991">							
						<?php echo $__env->make("inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
		
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("css"); ?>

<style type="text/css">
	
/* tab program */

.nav-program .nav-item .nav-link {
  padding: 10px 20px;
  border-radius: 0;
  color: #555;
  border: none;
  font-weight: bold;
}

.nav-program .nav-item .nav-link.active {
	background: #1a976c;
	color: #fff;
}

.nav-program {
    border-bottom: 2px solid #1a976c;
}

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/anggota_program.blade.php ENDPATH**/ ?>