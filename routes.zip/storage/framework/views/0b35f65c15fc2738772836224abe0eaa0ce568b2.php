<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Anggota']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(route("program.index")); ?>">Program</a></li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-12">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="white-box">
                        <h5><b><?php echo e($program->judul); ?></b></h5>
                        <hr>
                        <div class="text-right">
                            <a href="<?php echo e(route('anggota_program.add', ['id_program' => $program->id])); ?>" class="btn btn-success waves-effect waves-light"
                                type="button"><span class="btn-label"><i class=" zmdi zmdi-plus-circle"></i></span>Tambah Baru</a>
                        </div>
                        <div class="table-responsive m-t-20">
                            <table class="table" id="tableTour">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Foto</th>
                                        <th>Nama</th>
                                        <th>Umur</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($data)): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i +1); ?></td>
                                        <td>
                                             <a href="<?php echo e(asset("website/images/anggota_program/".$row->foto)); ?>" target="_blank">
                                                <img class="img-circle img-thumbnail" width="50" src="<?php echo e(asset("website/images/anggota_program/".$row->foto)); ?>" alt="IMG">
                                            </a>
                                        </td>
                                        <td><?php echo e($row->nama); ?></td>
                                        <td><?php echo e($row->umur); ?> Tahun</td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('anggota_program.ganti_foto', ['id' => $row->id])); ?>" class="btn btn-info waves-effect waves-light"><span
                                                    class="btn-label"><i class="zmdi zmdi-photo-size-select-large"></i></span>Ganti foto</a>
                                            <a href="<?php echo e(route('anggota_program.edit', ['id' => $row->id])); ?>" class="btn btn-primary waves-effect waves-light"><span
                                                    class="btn-label"><i class="zmdi zmdi-edit"></i></span>Edit</a>
                                            <button data-id="<?php echo e($row->id); ?>" class="btn btn-delete-aanggota-program btn-danger waves-effect waves-light"
                                                type="button"><span class="btn-label"><i class="zmdi zmdi-delete"></i></span>Hapus</button>
                                            <form id="formDelete<?php echo e($row->id); ?>" method="POST" action="<?php echo e(route('anggota_program.destroy', ['id' => $row->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("DELETE"); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td class="text-center" colspan="4">Data Kosong</td>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/plugins/bower_components/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<script>
    $("#tableTour").DataTable({
        "fnDrawCallback": function (oSettings) {
            //Anggota Program
            $(".btn-delete-aanggota-program").click(function () {
                let button = $(this)
                Swal({
                    title: "Anda Yakin?",
                    text: "Data anggota ini akan terhapus secara permanen",
                    type: "warning",
                    showCancelButton: true,
                    cancelButtonText: "Tidak",
                    confirmButtonColor: "#ea6554",
                    confirmButtonText: "Ya, lanjutkan!"
                }).then(function (result) {
                    if (result.value) {
                        $("#formDelete" + button.data("id")).submit()
                    }
                });
            })
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/anggota_program/index.blade.php ENDPATH**/ ?>