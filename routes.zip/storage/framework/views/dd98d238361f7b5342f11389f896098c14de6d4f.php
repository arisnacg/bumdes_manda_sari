<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $__env->yieldContent("title"); ?> BUMDES Mandala Sari</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(asset("website/images/icons/favicon.png")); ?>"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/vendor/bootstrap/css/bootstrap.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/fonts/fontawesome-5.0.8/css/fontawesome-all.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/fonts/iconic/css/material-design-iconic-font.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/vendor/animate/animate.css")); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/vendor/css-hamburgers/hamburgers.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/vendor/animsition/css/animsition.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/css/util.min.css")); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("website/css/main.css")); ?>">
<!--===============================================================================================-->
	<?php echo $__env->yieldContent("css"); ?>
</head>
<body class="animsition">
	
	<?php echo $__env->make("inc.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<span class="fas fa-angle-up"></span>
		</span>
	</div>
<!--===============================================================================================-->	
	<script src="<?php echo e(asset("website/vendor/jquery/jquery-3.2.1.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("website/vendor/animsition/js/animsition.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("website/vendor/bootstrap/js/popper.js")); ?>"></script>
	<script src="<?php echo e(asset("website/vendor/bootstrap/js/bootstrap.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("website/js/main.js")); ?>"></script>
	<?php echo $__env->yieldContent("js"); ?>
</body>
</html><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/app.blade.php ENDPATH**/ ?>