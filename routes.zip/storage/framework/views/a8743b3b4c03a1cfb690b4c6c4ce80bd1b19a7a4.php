<?php $__env->startSection('body'); ?>

<div id="wrapper">
    <?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Kerja Sama']); ?>
            <li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
            <?php echo $__env->renderComponent(); ?>
            <!-- .row -->
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-9">
                    <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="white-box">
                        <div class="text-right">
                            <a href="<?php echo e(route('kerjasama.create')); ?>" class="btn btn-success waves-effect waves-light"
                                type="button"><span class="btn-label"><i class=" zmdi zmdi-plus-circle"></i></span>Tambah Baru</a>
                        </div>
                        <div class="table-responsive m-t-20">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($data)): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i +1); ?></td>
                                        <td><?php echo e($row->nama); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('kerjasama.edit', ['id' => $row->id])); ?>" class="btn btn-primary waves-effect waves-light"><span
                                                    class="btn-label"><i class="zmdi zmdi-edit"></i></span>Edit</a>
                                            <button data-id="<?php echo e($row->id); ?>" class="btn btn-delete-kategori-blog btn-danger waves-effect waves-light"
                                                type="button"><span class="btn-label"><i class="zmdi zmdi-delete"></i></span>Hapus</button>
                                            <form id="formDelete<?php echo e($row->id); ?>" method="POST" action="<?php echo e(route('kerjasama.destroy', ['id' => $row->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("DELETE"); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td class="text-center" colspan="4">Data Kosong</td>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/kerjasama/index.blade.php ENDPATH**/ ?>