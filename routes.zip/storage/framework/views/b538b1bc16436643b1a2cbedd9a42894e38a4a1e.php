<?php if(session('success')): ?>
    <div class="alert alert-success">
        <i class="ti-check m-r-20"></i> <?php echo session('success'); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="zmdi zmdi-close"></i>
        </button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <i class="ti-alert m-r-20"></i> <?php echo session('error'); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="zmdi zmdi-close"></i>
        </button>
    </div>
<?php endif; ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/inc/alert.blade.php ENDPATH**/ ?>