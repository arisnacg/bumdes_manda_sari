<?php $__env->startSection('body'); ?>

<div id="wrapper">
	<?php echo $__env->make('dashboard.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Page Content -->
	<div id="page-wrapper">
		<div class="container-fluid">
			<?php $__env->startComponent('dashboard.components.breadcrumb', ['pagename' => 'Tambah Baru']); ?>
			<li><a href="<?php echo e(route("dashboard")); ?>">Dashboard</a></li>
			<li><a href="<?php echo e(route("kategori_blog.index")); ?>">Kategori Blog</a></li>
			<?php echo $__env->renderComponent(); ?>
            <!-- .row -->
			<div class="row justify-content-center">
					<div class="col-sm-12 col-md-8">
                            <?php echo $__env->make('dashboard.inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<form class="form-horizontal" method="POST" action="<?php echo e(route('kategori_blog.store')); ?>" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="panel panel-default">
										<div class="panel-heading text-muted">Kategori Blog <span class="label label-info m-l-5">Baru</span></div>
										<div class="panel-wrapper collapse in">
												<div class="panel-body">
													<div class="form-group row <?php echo e($errors->has('nama') ? 'has-danger' : ''); ?>">
														<label class="col-sm-12 col-md-2">Nama</label>
														<div class="col-sm-12 col-md-10">
															<input name="nama" type="text" class="form-control" value="<?php echo e(old('nama')); ?>">
															<?php if($errors->has('nama')): ?>
																<div class="form-control-feedback"><?php echo e($errors->first('nama')); ?></div>
															<?php endif; ?>
														</div>
                                                    </div>
												</div>
												<div class="panel-footer text-right">
														<a href="<?php echo e(route('kategori_blog.index')); ?>" type="submit" class="btn btn-default waves-effect waves-light m-r-5" type="button"><span class="btn-label"><i class="zmdi zmdi-long-arrow-return"></i></span> Kembali</a>
														<button type="submit" class="btn btn-success waves-effect waves-light" type="button"><span class="btn-label"><i class=" zmdi zmdi-save"></i></span> Simpan</button>
												</div>
										</div>
								</div>
							</form>
					</div>
			</div>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
	<?php echo $__env->make('dashboard.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/dashboard/kategori_blog/create.blade.php ENDPATH**/ ?>