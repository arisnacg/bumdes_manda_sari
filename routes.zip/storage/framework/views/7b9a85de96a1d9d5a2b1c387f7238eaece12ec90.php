<?php $__env->startSection('content'); ?>
		
	<!-- Headline -->
	<div class="container">
		<div class="bg0 flex-wr-sb-c p-rl-20 p-tb-8">
			<div class="f2-s-1 p-r-30 size-w-0 m-tb-6 flex-wr-s-c">
				<span class="text-uppercase cl2 p-r-8">
					Beranda
				</span>
			</div>

			<div class="pos-relative size-a-2 bo-1-rad-22 of-hidden bocl11 m-tb-6">
				<input class="f1-s-1 cl6 plh9 s-full p-l-25 p-r-45" type="text" name="search" placeholder="Search">
				<button class="flex-c-c size-a-1 ab-t-r fs-20 cl2 hov-cl10 trans-03">
					<i class="zmdi zmdi-search"></i>
				</button>
			</div>
		</div>
	</div>
		
	<!-- Feature post -->

	<!-- Usaha -->
	<section class="bg0 p-t-70">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-sm-12 col-md-8">
					<!-- Jenis Usaha -->
					<?php if(count($data["jenis_unit_usaha"])): ?>
						<?php $__currentLoopData = $data["jenis_unit_usaha"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $jenis_unit_usaha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(count($jenis_unit_usaha->unit_usaha)): ?>
								<?php if($i % 2 == 0): ?>
									<div class="row"> <!-- row :<?php echo e($i); ?> -->
								<?php endif; ?>
								<div class="col-sm-6 p-r-25 p-r-15-sr991 p-b-25">
									<div class="how2 how2-cl2 flex-sb-c m-b-35">
										<h3 class="f1-m-2 cl13 tab01-title">
											<?php echo e($jenis_unit_usaha->nama); ?>

										</h3>
										
									</div>
									<?php $__currentLoopData = $jenis_unit_usaha->unit_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $unit_usaha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($j == 0): ?>
											<div class="m-b-30">
												<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="wrap-pic-w hov1 trans-03">
													<img src="<?php echo e(asset("website/images/usaha/".$unit_usaha->gambar)); ?>" alt="IMG">
												</a>
												<div class="p-t-20">
													<h5 class="p-b-5">
														<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="f1-m-3 cl2 hov-cl10 trans-03">
															<?php echo e($unit_usaha->nama); ?>

														</a>
													</h5>
													<span class="cl8">
														<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="f1-s-6 cl8 hov-cl10 trans-03">
															Baca Selengkapnya <i class="zmdi zmdi-arrow-right m-l-5"></i>
														</a>
													</span>
												</div>
											</div>
										<?php else: ?>
											<div class="flex-wr-sb-s m-b-30">
												<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="size-w-1 wrap-pic-w hov1 trans-03">
													<img src="<?php echo e(asset("website/images/usaha/".$unit_usaha->gambar)); ?>" alt="IMGDonec metus orci, malesuada et lectus vitae">
												</a>

												<div class="size-w-2">
													<h5 class="p-b-5">
														<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="f1-s-5 cl3 hov-cl10 trans-03">
															<?php echo e($unit_usaha->nama); ?>

														</a>
													</h5>

													<span class="cl8">
														<a href="<?php echo e(route("page.unit_usaha", ["url" => $unit_usaha->url])); ?>" class="f1-s-6 cl8 hov-cl10 trans-03">
															Baca Selengkapnya <i class="zmdi zmdi-arrow-right m-l-5"></i>
														</a>
													</span>
												</div>
											</div>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								<?php if($i % 2 == 1): ?>
									</div> <!-- <?php echo e($i); ?> -->
								<?php endif; ?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					
				</div>
				<div class="col-md-4">
					<?php echo $__env->make("inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>
		</div>
	</section>

	<!-- Banner -->
	

	<!-- Latest -->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Project\bumdes_mandala_sari\resources\views/index2.blade.php ENDPATH**/ ?>